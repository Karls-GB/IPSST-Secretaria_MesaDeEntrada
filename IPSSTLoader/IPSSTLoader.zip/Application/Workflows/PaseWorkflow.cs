﻿using IPSST.Domain.Entities;
using IPSSTLoader.Domain.Entities;
using IPSSTLoader.Domain.Enums;
using IPSSTLoader.Domain.Interface;
using IPSSTLoader.Domain.Validation;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;

namespace IPSSTLoader.Application.Workflows;

public class PaseWorkflow
{
    private readonly IAutomationPase _automationPase;
    private readonly IUploadJobRepository _uploadJobRepository;
    private readonly ExpValidation _expValidation;

    public PaseWorkflow(IAutomationPase automationPase,
        IUploadJobRepository uploadJobRepository,
        ExpValidation expValidation)
    {
        _automationPase = automationPase;
        _uploadJobRepository = uploadJobRepository;
        _expValidation = expValidation;
    }

    public async Task<PasePreparation?> PrepararAsync(string nroExpediente)
    {
        return await _automationPase.PrepararPaseAsync(nroExpediente);
    }

    public void ValidateExp(string nroExpediente)
    {
        var tempExpediente = new Expediente { NroExpediente = nroExpediente };
        var validationResult = _expValidation.Validate(tempExpediente, ExpValidationContext.Busqueda);

        if (!validationResult.IsValid)
        {
            throw new ArgumentException(string.Join(", ", validationResult.Errors));
        }
    }

    public async Task ExecuteAsync(Expediente expediente, bool isRetry = false, int maxRetries = 3, UploadJob? existingJob = null)
    {
        //Asignar Id si no lo tiene
        if(expediente.Id == default)
        {
            expediente.Id = Guid.NewGuid();
        }
        
        //Validacion
        var validationResult = _expValidation.Validate(expediente, ExpValidationContext.Pase);
        if (!validationResult.IsValid)
        {
            throw new ArgumentException(string.Join(", ", validationResult.Errors));
        }

        //Crear Trabajo de subida O Usar Uno Existente
        UploadJob job;

        if (existingJob != null)
        {
            job = existingJob;
            job.PaseDataJson = JsonSerializer.Serialize(expediente.Pase);
        }
        else
        {
            job = new UploadJob
            {
                Id = Guid.NewGuid(),
                ExpedienteId = expediente.Id,
                NroExpediente = expediente.NroExpediente,
                Status = UploadStatus.Pending,
                CreatedAt = DateTime.UtcNow,
                PaseDataJson = JsonSerializer.Serialize(expediente.Pase)
            };

            await _uploadJobRepository.AddAsync(job);
        }

        //Comprobar si se esta reintentando la subida
        if (isRetry)
        {
            job.RetryCount++;
        }

        await _uploadJobRepository.UpdateAsync(job);

        //Ejecucion y Logica de Reintento
        int attempt = 0;

        while(attempt < maxRetries)
        {
            job.Status = UploadStatus.InProgress;
            job.StartedAt = DateTime.UtcNow;
            await _uploadJobRepository.UpdateAsync(job);

            try
            {
                var success = await _automationPase.ConfirmarPaseAsync(
                    expediente.Pase!.OficinaDestino,
                    expediente.Pase.Folios,
                    expediente.Pase.Observaciones ?? string.Empty);

                if (success)
                {
                    job.Status = UploadStatus.Completed;
                    job.CompletedAt = DateTime.UtcNow;
                    await _uploadJobRepository.UpdateAsync(job);
                    return;
                }
                else
                {
                    job.RetryCount++;
                    attempt++;
                    job.LastError = "Fallo de Pase en Playwright";

                    if(attempt < maxRetries)
                    {
                        await Task.Delay(5000);
                    }
                }
            }
            catch(Exception ex) 
            {
                job.RetryCount++;
                attempt++;
                job.LastError = ex.Message;

                if(attempt >= maxRetries)
                {
                    job.Status = UploadStatus.Failed;
                    await _uploadJobRepository.UpdateAsync(job);
                    throw;
                }

                await Task.Delay(5000);
            }
        }

        //Intentos Agotados
        job.Status = UploadStatus.Failed;
        job.LastError = "Se Alcanzaron los Intentos Maximos de Pase";
        await _uploadJobRepository.UpdateAsync(job);
    }
}
